//burger menu
function openmenu() {
    document.getElementById("sidenav").style.width = "250px";
  
  }
  
  function closemenu() {
    document.getElementById("sidenav").style.width = "0";
  
  }


//slider
let slideimages = document.querySelectorAll('.sl');
let next = document.querySelector('.next');
let prev = document.querySelector('.prev');
let dots = document.querySelectorAll('.dot');
var counter = 0;

next.addEventListener('click', slidenext);
function slidenext(){
  slideimages[counter].style.animation = 'next1 0.5s ease-in forwards';
  if(counter >= slideimages.length-1){
    counter = 0;
  }
  else{
    counter++;
  }
  slideimages[counter].style.animation ='next2 0.5s ease-in forwards'
indicators();
}


prev.addEventListener('click', slideprev);
function slideprev(){
  slideimages[counter].style.animation = 'prev1 0.5s ease-in forwards';
  if(counter == 0){
    counter=slideimages.length-1;
  }
  else{
    counter--;
  }
  slideimages[counter].style.animation ='prev2 0.5s ease-in forwards';
indicators();
}

function autosliding(){
  deletInterval= setInterval(timer,2000);
  function timer(){
    slidenext();
    indicators();
  }
}
autosliding();

function indicators(){
  for(i=0; i <dots.length; i++){
    dots[i].className = dots[i].className.replace('active', '');
  }
  dots[counter].className += ' active';
}


function switchimage(currentimage){
  currentimage.classList.add('active');
  var imageId = currentimage.getAttribute('atrr');
  if (imageId > counter){
    slideimages[counter].style.animation = 'next1 0.5s ease-in forwards';
    counter = imageId;
    slideimages[counter].style.animation= 'next2 0.5s ease-in forwards';
  }
  else if(imageId == counter){
    return;
  }
  else{
    slideimages[counter].style.animation = 'prev1 0.5s ease-in forwards';
    counter = imageId;
    slideimages[counter].style.animation= 'prev2 0.5s ease-in forwards';
  }

  
}